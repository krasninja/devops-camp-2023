<?php 
  phpinfo(); 
?>


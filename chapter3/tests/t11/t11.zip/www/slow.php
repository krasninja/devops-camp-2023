<?php
  sleep(10 * 60);
  print('SLOW REPORT');
?>
